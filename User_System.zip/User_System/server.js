const express = require("express");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const userModel = require("./Models/user.model");
const postModel = require("./Models/post.model");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ express: true }));

app.use(cookieParser());

app.set("view engine", "ejs");


// front-end logic
app.get("/", (req, res) => {
    res.render("index");
});

app.get("/signup", (req, res) => {
    res.render("signup");
});

app.get("/profile", auth , (req, res) => {
    res.render("profile");
});

// back-end logic + database
// signup user => create a new user
app.post("/create", (req, res) => {
    let { fullname, username, email, phone, profile, password } = req.body;

    bcrypt.hash(password, 10, async (err, hash) => {
        try {
            await userModel.create({
                fullname,
                username,
                email,
                phone,
                password: hash,
                profile
            });
        } catch (err) {
            console.log(err);
        }
    });
    res.redirect("/");
});

// login user => check email and password, redirect to profile page
app.post("/login", async (req, res) => {
    let user = await userModel.findOne({ email: req.body.email });

    if (!user) {
        res.send("Something Went Wrong - Email");
    } else {
        bcrypt.compare(req.body.password, user.password, (err, result) => {
            if (result) {
                let token = jwt.sign({ email: user.email }, "krishna");
                res.cookie("token", token);
                res.redirect("/profile");
            } else {
                res.send("Something Went Wrong");
            }
        });
    }
});

app.get("/logout",(req , res)=>{
   res.clearCookie();
   res.redirect("/");
} );

//Middleware functions
function auth (req , res , next){
   // console.log(req.cookies);
   let token = req.cookies.token;
   if (!token) {
      res.send("Access Denied !!");
   }

   try {
      let verified = jwt.verify(token , "krishna" );
      verified = req.user;  // this data send into next route (check profile route , ypou can access email)
   } catch (err) {
      console.log("Invalid Token");
   }
}



app.listen(3000, () => {
    console.log("Server is on localhost:3000");
});