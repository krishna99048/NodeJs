const mongoose = require("mongoose");

let permissionSchema = mongoose.Schema({
    name: {
        type: String,
        minLenght: 3,
        unique: true, 
        required: true
    },
    isActive: {
        type: Boolean,
        default: false
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user"
    }
});

module.exports = mongoose.model("permission", permissionSchema);